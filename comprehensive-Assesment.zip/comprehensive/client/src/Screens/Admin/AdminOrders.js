import React from 'react';

const AdminOrders = () => (
	<div>
		<h1 className="p-2 text-3xl font-mono align-left ml-20">Admin Orders</h1>
	</div>
);

export default AdminOrders;
