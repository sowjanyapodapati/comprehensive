import React from 'react';

const SearchBar = () => (
		
	<div className="flex items-center justify-between p-3">
		<div className="flex items-center flex-wrap">
			<h1 className="text-5xl font-mono font-style: italic text-purple-900 text-center ">
				✖️pharmacy Online
			
			</h1>
		</div>
	

		<input
			className="w-full p-2 border-2 border-rose-500 focus:outline-none focus:border-red-300"
			type="text"
			placeholder="Search"
		/>
		{/* search button */}
		<button className="bg-rose-500 ">
			<svg
				className="w-8 h-11"
				fill="none"
				strokeLinecap="round"
				strokeLinejoin="round"
				strokeWidth="2"
				viewBox="0 0 24 24"
				stroke="currentColor">
				<path d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
			</svg>
		</button>
	</div>
);

export default SearchBar;
