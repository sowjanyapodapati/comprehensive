import React from 'react';
import Header from './Header';
import SearchBar from './SearchBar';
import CategoryBar from './CategoryBar';
import SlideShow from './SlideShow';

import { useLocation } from 'react-router-dom';

const Base = ({ title, children }) => {
  const flage = useLocation().pathname === '/';

  return (
    <div className='flex flex-col min-h-screen'>
      <Header />
    
      {flage ? (
        <>
          <SearchBar />
          <marquee direction="right" className=" bg-sky-500 py-2 px-5 font-serif text-xl text-white ">Hello User Welcome to Online Pharmacy Store🏥 Application </marquee>
          <SlideShow/>   
          </>
      ) : null}

      <div className='flex items-center justify-center m-8'>
        <h1 className='text-3xl font-Brush Script MT, Brush Script Std, cursive'>{title}</h1>
      </div>
      <main className='flex-grow'>{children}</main>
      <footer className='flex items-center justify-center bg-blue-400 p-6'>
        <span className='text-sm text-white'>
          © {new Date().getFullYear()}, Developed by
          <a> ABC </a>
        </span>
      </footer>
    </div>
  );
};
export default Base;
