import React from 'react';
import { Slide } from 'react-slideshow-image';
import './SlideShow.css';
import 'react-slideshow-image/dist/styles.css';
const slideImages = [
    'https://bsmedia.business-standard.com/_media/bs/img/article/2018-09/23/full/1537715038-2426.jpg',
    'https://media.istockphoto.com/photos/shopping-cart-toy-with-medicaments-in-front-of-laptop-screen-with-picture-id1132186568?k=20&m=1132186568&s=612x612&w=0&h=cLwr42_0GZSiBuYuwKBwF_lLxC1g2YPmWgoJrY7B1Ls=',
    'https://media.istockphoto.com/photos/mobile-service-or-app-for-purchasing-medicines-in-online-pharmacy-picture-id1215516053?k=20&m=1215516053&s=612x612&w=0&h=2xBSfamxJBaZJufqxYnHd557Fzc6cWelSGQ5AvJJRvo=',
    'https://media.istockphoto.com/photos/male-pharmacist-using-mobile-phone-at-pharmacy-picture-id1074065412?k=20&m=1074065412&s=612x612&w=0&h=Y7BmjDeGdvCvhDfo0YiKQ3k9_823D9aLISJCfaysckE='
  
];

const Slideshow = () => {
    return (
      <div>
        <Slide easing="ease">
          <div className="each-slide">
            <div style={{'backgroundImage': `url(${slideImages[0]})`}}>
             
            </div>
          </div>
          <div className="each-slide">
            <div style={{'backgroundImage': `url(${slideImages[1]})`}}>
              
            </div>
          </div>
          <div className="each-slide">
            <div style={{'backgroundImage': `url(${slideImages[2]})`}}>
             
            </div>
          </div>
        </Slide>
      </div>
    )
};

export default Slideshow;